// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <cstring> 

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::string temp;
  std::cout << "Enter a value: ";
  // temp variable to help witht the prevention of overflow
  std::cin >> temp;

  if (temp.length() > 20) {
	  // if temp is to long, throw an error
	  std::cout << "Buffer Overflow detected. Please only enter a max of 20 characters." << std::endl;
  }
  else {
	  // else, convert string to character array and continue
	  strcpy_s(user_input, temp.c_str());

	  std::cout << "You entered: " << user_input << std::endl;
	  std::cout << "Account Number = " << account_number << std::endl;
  }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
